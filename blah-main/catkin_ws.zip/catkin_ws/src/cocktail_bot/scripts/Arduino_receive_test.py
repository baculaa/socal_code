#!/usr/bin/python

import socket
import sys
import rospy
from std_msgs.msg import String

rospy.init_node('pressed', anonymous=True)
ButtonPressed=rospy.Publisher('chat', String, queue_size=10)
 
HOST ='localhost' # Symbolic name, meaning all available interfaces
PORT = 8000 # Arbitrary non-privileged port
 
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
print ('Socket created')

try:
	s.bind((HOST, PORT))
except:
	print('Bind failed. Error Code : ' + str(msg[0]) +'Message' + msg[1])
	sys.exit()
print('socket bind complete')

s.listen(10)
print('socket now listening')

#s.connect(('192.168.2.162',PORT))
#print('connected')
#msg =s.recv(1024)
#rint('message:'+msg)
#while msg:
#	print('message received:' + msg.decode())
#	msg=s.recv(1024)
#.close() 

def pressed():
	#now keep talking with the client
	while not rospy.is_shutdown():
		while True:
		#wait to accept a connection - blocking call
			conn, addr = s.accept()
			data = conn.recv(1024)
			print ('Connected with ' + addr[0] + ':' + str(addr[1]) + " " )
			message = str(data.decode("utf-8"))
			if message =="Button was pressed" :
				ButtonPressed.publish(message)
				#rospy.sleep(10)
		 
		s.close()

if __name__ == '__main__' :
    try:
    	pressed()
    except rospy.ROSInterruptException:
    	pass

