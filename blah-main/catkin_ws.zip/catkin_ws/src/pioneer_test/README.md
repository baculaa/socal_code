# pioneer_test
ROS packages for Pioneer3dx platform testing.

Use in conjunction with pioneer_2dnav package with re-tuned parameters for on-platform testing and simple_navigation_goals for sending geometry_msgs/Twist waypoints in the base_link or map frame. 
