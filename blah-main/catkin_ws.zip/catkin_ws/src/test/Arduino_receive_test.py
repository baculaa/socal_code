#!/usr/bin/python

import socket
import sys
import rospy
from std_msgs.msg import String

rospy.init_node('pressed', anonymous=True)
ButtonPressed=rospy.Publisher('chat', String, queue_size=10)
 
HOST = '' # Symbolic name, meaning all available interfaces
PORT = 8888 # Arbitrary non-privileged port
 
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
print ('Socket created')
 
#Bind socket to local host and port
try:
	s.bind((HOST, PORT))
except socket.error as msg:
	print ('Bind failed. Error Code : ' + str(msg[0]) + ' Message ' + msg[1])
	sys.exit()
 
print ('Socket bind complete')
 
#Start listening on socket
s.listen(10)
print ('Socket now listening')

def pressed():
	#now keep talking with the client
	while not rospy.is_shutdown():
		while True:
		#wait to accept a connection - blocking call
			conn, addr = s.accept()
			data = conn.recv(1024)
			print ('Connected with ' + addr[0] + ':' + str(addr[1]) + " " )
			message = str(data.decode("utf-8"))
			if message =="Button was pressed" :
				ButtonPressed.publish(message)
				print(message)
				#rospy.sleep(10)
		 
		s.close()

if __name__ == '__main__' :
    try:
    	pressed()
    except rospy.ROSInterruptException:
    	pass
    try:	
		s.bind((HOST, PORT))
    except socket.error as msg:
		print ('Bind failed. Error Code : ' + str(msg[0]) + ' Message ' + msg[1])
		sys.exit()