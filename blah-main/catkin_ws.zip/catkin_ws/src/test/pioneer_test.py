#!/usr/bin/env python
import rospy 
# from std_msgs.msg import String
from geometry_msgs.msg import Twist


def pos():
	while not rospy.is_shutdown():
	    # set your move values
	    move.linear.x=0.05; move.linear.y=0.0; move.linear.z=0.0;
            print(move)
	move.angular.x=0.0; move.angular.y=0.0; move.angular.z=0.0;
        # vel_str= "Moving at (" + str(move.linear.x) + ", " +str(move.linear.y) + ", " + str(move.linear.z) + ")"
        pub.publish(move)
        rospy.sleep(5)
        move.linear.x=0.0; move.linear.y=0.0; move.linear.z=0.0;
        move.angular.x=0.0; move.angular.y=0.0; move.angular.z=0.0;
        pub.publish(move)
        rospy.sleep(10)
    # vel_str= "Moving at (" + str(move.linear.x) + ", " +str(move.linear.y) + ", " + str(move.linear.z) + ")"
    # pub.publish(vel_str)
    # shutDown=True

if __name__ == '__main__' :
    rospy.init_node('pos', anonymous=True)
    pub=rospy.Publisher("cmd_vel", Twist, queue_size=10)

    rate =rospy.Rate(10)
    move = Twist()

